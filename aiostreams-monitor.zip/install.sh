#!/usr/bin/env bash
# ============================================================
# AIOStreams Monitor Installer for Arrstack
# ============================================================
set -e

# Find the directory where this script and the monitor files are located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

echo "=== [1/6] Preparing AIOStreams Custom Build ==="
BUILD_DIR="aiostreams-custom-build"
rm -rf "$BUILD_DIR"
git clone https://github.com/Viren070/AIOStreams.git "$BUILD_DIR"

echo "=== [2/6] Copying Monitor Files ==="
mkdir -p "$BUILD_DIR/packages/server/src/static/monitor"

cp "$SCRIPT_DIR/packages/server/src/middlewares/stream-monitor.ts" "$BUILD_DIR/packages/server/src/middlewares/"
cp "$SCRIPT_DIR/app.js" "$BUILD_DIR/packages/server/src/static/monitor/"
cp "$SCRIPT_DIR/index.css" "$BUILD_DIR/packages/server/src/static/monitor/"
cp "$SCRIPT_DIR/index.html" "$BUILD_DIR/packages/server/src/static/monitor/"

cd "$BUILD_DIR"

echo "=== [3/6] Patching Server Source Code ==="

# Patch middlewares/index.ts
echo "export * from './stream-monitor.js';" >> packages/server/src/middlewares/index.ts

# Patch app.ts - Add imports
sed -i "s/requireSessionIfAuthRequired,/requireSessionIfAuthRequired,\n  streamMonitorMiddleware,\n  createMonitorRouter,/" packages/server/src/app.ts

# Patch app.ts - Add streamMonitorMiddleware after loggerMiddleware
sed -i "s/app.use(loggerMiddleware);/app.use(loggerMiddleware);\napp.use(streamMonitorMiddleware);/" packages/server/src/app.ts

# Patch app.ts - Mount /monitor router before Stremio Routes
sed -i "s/\/\/ Stremio Routes/\/\/ Stream Monitor Dashboard\napp.use('\/monitor', createMonitorRouter());\n\n\/\/ Stremio Routes/" packages/server/src/app.ts

# Patch Dockerfile to copy static files
sed -i "s/COPY packages\/server .\/packages\/server/COPY packages\/server .\/packages\/server\nCOPY packages\/server\/src\/static\/monitor .\/packages\/server\/src\/static\/monitor/" Dockerfile

echo "=== [4/6] Building Custom Docker Image (this may take a few minutes on ARM64) ==="
docker build -t aiostreams-monitor:latest .

cd ..
rm -rf "$BUILD_DIR"

echo "=== [5/6] Updating docker-compose.yml ==="
if [ -f "docker-compose.yml" ]; then
    sed -i 's/image: ghcr.io\/viren070\/aiostreams:latest/image: aiostreams-monitor:latest/' docker-compose.yml
    # Also ensure image is updated if it was already changed to aiostreams-monitor before
    sed -i 's/image: aiostreams-monitor:latest/image: aiostreams-monitor:latest/' docker-compose.yml

    # Add host /proc/net/dev volume mount for overall instance bandwidth monitoring
    # Only add if not already present
    if ! grep -q "/host/proc/net/dev" docker-compose.yml; then
        # Find the volumes section under aiostreams service and add the mount
        # We use a Python one-liner for reliable YAML insertion
        python3 -c "
import re
with open('docker-compose.yml', 'r') as f:
    content = f.read()

# Find existing volume mount in aiostreams section and add after it
# Look for a line like '      - ./something:/something' under aiostreams volumes
lines = content.split('\n')
new_lines = []
in_aiostreams = False
added = False
for i, line in enumerate(lines):
    new_lines.append(line)
    # Detect we're in the aiostreams service
    if re.match(r'^\s+aiostreams:', line):
        in_aiostreams = True
    # If we hit another top-level service, stop looking
    elif in_aiostreams and re.match(r'^\s+\w+:', line) and not line.strip().startswith('-') and not line.strip().startswith('#'):
        if not line.strip().startswith('env_file') and not line.strip().startswith('ports') and not line.strip().startswith('volumes') and not line.strip().startswith('image') and not line.strip().startswith('container_name') and not line.strip().startswith('restart') and not line.strip().startswith('networks') and not line.strip().startswith('depends_on') and not line.strip().startswith('environment') and not line.strip().startswith('labels') and not line.strip().startswith('logging'):
            in_aiostreams = False
    # Add the volume mount after an existing volume line in aiostreams
    if in_aiostreams and not added and re.match(r'^\s+-\s+\./.*:.*', line):
        indent = re.match(r'^(\s+-\s+)', line).group(1)
        new_lines.append(indent + '/proc/net/dev:/host/proc/net/dev:ro')
        added = True

with open('docker-compose.yml', 'w') as f:
    f.write('\n'.join(new_lines))
" 2>/dev/null || echo "Note: Could not auto-add volume mount. Please add '- /proc/net/dev:/host/proc/net/dev:ro' under aiostreams volumes manually."
    fi

    echo "docker-compose.yml updated successfully."
else
    echo "Warning: docker-compose.yml not found in current directory. Please update it manually."
fi

# Add Env vars to .env.aiostreams if not present
if [ -f ".env.aiostreams" ]; then
    if ! grep -q "MONITOR_CONCURRENT_LIMIT" .env.aiostreams; then
        echo "" >> .env.aiostreams
        echo "# Monitor Settings" >> .env.aiostreams
        echo "MONITOR_CONCURRENT_LIMIT=4" >> .env.aiostreams
        echo "MONITOR_SESSION_TIMEOUT=300000" >> .env.aiostreams
    fi
fi

echo "=== [6/6] Restarting AIOStreams Container ==="
if command -v docker-compose &> /dev/null; then
    docker-compose up -d aiostreams
elif docker compose version &> /dev/null; then
    docker compose up -d aiostreams
else
    echo "Docker compose not found, please start the container manually."
fi

echo ""
echo "============================================================"
echo "✅ Installation Complete!"
echo "The monitor is now available at: /monitor"
echo "Note: If using Nginx Proxy Manager, don't forget to protect"
echo "the /monitor path with Basic Auth or Access Lists."
echo "============================================================"
