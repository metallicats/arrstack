/**
 * AIOStreams Stream Monitor Middleware
 *
 * Tracks concurrent stream sessions per user config UUID and actively
 * blocks new streams when the configured concurrent limit is exceeded.
 *
 * Sessions are keyed by the userData segment from the Stremio URL path
 * (e.g. /:userData/stream/movie/:id.json). Each unique userData gets
 * its own UUID-identified session entries.
 *
 * Environment variables:
 *   MONITOR_CONCURRENT_LIMIT  — max concurrent streams per user (default: 4)
 *   MONITOR_SESSION_TIMEOUT   — ms before idle session expires (default: 300000 = 5min)
 */

import express, { Router, Request, Response, NextFunction } from 'express';
import { randomUUID } from 'crypto';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createLogger } from '@aiostreams/core';

const logger = createLogger('stream-monitor');

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export interface StreamSession {
  uuid: string;
  userConfig: string;
  ip: string;
  userAgent: string;
  contentType: string;
  contentId: string;
  contentTitle: string;
  firstSeen: number;
  lastSeen: number;
  requestPath: string;
}

export interface Violation {
  uuid: string;
  timestamp: number;
  userConfig: string;
  activeCount: number;
  limit: number;
  ip: string;
  contentId: string;
  blocked: boolean;
}

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

let CONCURRENT_LIMIT = parseInt(process.env.MONITOR_CONCURRENT_LIMIT || '4', 10);
let SESSION_TIMEOUT = parseInt(process.env.MONITOR_SESSION_TIMEOUT || '300000', 10);

// ---------------------------------------------------------------------------
// In-memory stores
// ---------------------------------------------------------------------------

// Map<sessionUUID, StreamSession>
const sessions = new Map<string, StreamSession>();

// Index: userConfig -> Set<sessionUUID>  (for fast per-user lookup)
const userSessions = new Map<string, Set<string>>();

const violations: Violation[] = [];

// Cache: contentId -> title (resolved via Cinemeta)
const titleCache = new Map<string, string>();

async function resolveTitle(contentType: string, contentId: string): Promise<string> {
  // contentId may contain season:episode suffix like tt1234567:1:2
  const baseId = contentId.split(':')[0];
  const cacheKey = `${contentType}/${baseId}`;

  if (titleCache.has(cacheKey)) {
    const cachedName = titleCache.get(cacheKey)!;
    if (cachedName === baseId) return contentId;

    const parts = contentId.split(':');
    if (parts.length >= 3) {
      return `${cachedName} S${parts[1].padStart(2, '0')}E${parts[2].padStart(2, '0')}`;
    }
    return cachedName;
  }

  // Mark as pending so we don't fire multiple requests for the same ID
  titleCache.set(cacheKey, baseId);

  try {
    const type = contentType === 'series' ? 'series' : 'movie';
    const url = `https://v3-cinemeta.strem.io/meta/${type}/${baseId}.json`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);

    if (res.ok) {
      const json = await res.json() as { meta?: { name?: string } };
      const name = json?.meta?.name;
      if (name) {
        titleCache.set(cacheKey, name);
        // If it's a series with episode info, append it
        const parts = contentId.split(':');
        if (parts.length >= 3) {
          return `${name} S${parts[1].padStart(2, '0')}E${parts[2].padStart(2, '0')}`;
        }
        return name;
      }
    }
  } catch {
    // Network error or timeout — return raw ID
  }

  return contentId;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Extract the config segment and stream info from a Stremio request path.
 * AIOStreams v2 paths look like: /stremio/:uuid/:encrypted/stream/:type/:id.json
 * or public ones: /stremio/stream/:type/:id.json
 */
const STREAM_PATH_REGEX = /^\/(.+)\/streams?\/([^/]+)\/(.+)\.json$/;

function getActiveSessionsForUser(userConfig: string): StreamSession[] {
  const uuids = userSessions.get(userConfig);
  if (!uuids) return [];
  const result: StreamSession[] = [];
  for (const uuid of uuids) {
    const s = sessions.get(uuid);
    if (s) result.push(s);
  }
  return result;
}

function deleteSession(uuid: string): boolean {
  const session = sessions.get(uuid);
  if (!session) return false;
  sessions.delete(uuid);
  const userSet = userSessions.get(session.userConfig);
  if (userSet) {
    userSet.delete(uuid);
    if (userSet.size === 0) userSessions.delete(session.userConfig);
  }
  return true;
}

// ---------------------------------------------------------------------------
// Cleanup: expire stale sessions
// ---------------------------------------------------------------------------

setInterval(() => {
  const now = Date.now();
  for (const [uuid, session] of sessions) {
    if (now - session.lastSeen > SESSION_TIMEOUT) {
      deleteSession(uuid);
    }
  }
}, 30_000);

// ---------------------------------------------------------------------------
// Middleware: track stream requests & enforce limits
// ---------------------------------------------------------------------------

export async function streamMonitorMiddleware(
  req: Request,
  res: Response,
  next: NextFunction
) {
  const match = req.path.match(STREAM_PATH_REGEX);
  
  if (!match) {
    // If the URL contains stream, log why it failed the regex
    if (req.path.includes('/stream')) {
      logger.debug(`[Monitor] Ignored stream-like path: ${req.path}`);
    }
    return next();
  }

  let [, userData, contentType, rawContentId] = match;
  // Fully URL-decode the content ID recursively to handle single/double/triple encoding
  let contentId = rawContentId;
  try {
    let prev = '';
    while (contentId !== prev && contentId.includes('%')) {
      prev = contentId;
      contentId = decodeURIComponent(contentId);
    }
  } catch {
    contentId = decodeURIComponent(rawContentId);
  }
  logger.info(`[Monitor] Detected stream request: User=${userData.substring(0, 15)}... Type=${contentType} ID=${contentId}`);
  
  const ipAddress =
    (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() ||
    req.socket.remoteAddress ||
    'unknown';
  const userAgent = req.headers['user-agent'] || 'Unknown';

  // AIOStreams v2 uses /stremio/stream for public, and /stremio/:uuid/:enc/stream for auth.
  // If userData is just 'stremio' or 'chilllink' (no UUID), we track by IP so they don't share one global limit.
  if (userData === 'stremio' || userData === 'chilllink') {
    userData = `public-${ipAddress}`;
  }

  // --- Find or create session for this user + content ---
  // A "session" is one user streaming one piece of content.
  // Same user + same content = same session (refresh/heartbeat).
  // Same user + different content = new concurrent session.
  const sessionKey = `${userData}::${contentId}`;
  let existingSession: StreamSession | undefined;

  const userUUIDs = userSessions.get(userData);
  if (userUUIDs) {
    for (const uuid of userUUIDs) {
      const s = sessions.get(uuid);
      if (s && s.contentId === contentId) {
        existingSession = s;
        break;
      }
    }
  }

  if (existingSession) {
    // Heartbeat — update lastSeen
    existingSession.lastSeen = Date.now();
    existingSession.ip = ipAddress;
    existingSession.userAgent = userAgent;
    existingSession.requestPath = req.path;
    return next();
  }

  // --- New stream request: check concurrent limit ---
  const currentCount = userUUIDs ? userUUIDs.size : 0;

  if (currentCount >= CONCURRENT_LIMIT) {
    // BLOCK: user already at or above their limit
    const violation: Violation = {
      uuid: randomUUID(),
      timestamp: Date.now(),
      userConfig: userData,
      activeCount: currentCount + 1,
      limit: CONCURRENT_LIMIT,
      ip: ipAddress,
      contentId,
      blocked: true,
    };
    violations.push(violation);
    if (violations.length > 1000) violations.splice(0, violations.length - 1000);

    logger.warn(
      `Blocked stream for user ${userData.substring(0, 8)}… — ` +
        `${currentCount}/${CONCURRENT_LIMIT} concurrent streams already active`
    );

    // Return a Stremio-compatible response with an error stream
    res.json({
      streams: [
        {
          name: 'AIOStreams',
          title: `⛔ Concurrent stream limit reached (${currentCount}/${CONCURRENT_LIMIT})`,
          description:
            'You have reached the maximum number of concurrent streams. ' +
            'Stop another stream before starting a new one.',
          url: '#',
          behaviorHints: { notWebReady: true },
        },
      ],
    });
    return;
  }

  // --- Allow: create new session ---
  const title = await resolveTitle(contentType, contentId);
  const newSession: StreamSession = {
    uuid: randomUUID(),
    userConfig: userData,
    ip: ipAddress,
    userAgent,
    contentType,
    contentId,
    contentTitle: title,
    firstSeen: Date.now(),
    lastSeen: Date.now(),
    requestPath: req.path,
  };

  sessions.set(newSession.uuid, newSession);
  if (!userSessions.has(userData)) {
    userSessions.set(userData, new Set());
  }
  userSessions.get(userData)!.add(newSession.uuid);

  // Warn if approaching limit
  const newCount = (userSessions.get(userData)?.size ?? 0);
  if (newCount >= CONCURRENT_LIMIT) {
    logger.info(
      `User ${userData.substring(0, 8)}… at capacity: ${newCount}/${CONCURRENT_LIMIT} streams`
    );
  }

  next();
}

// ---------------------------------------------------------------------------
// Monitor API Router
// ---------------------------------------------------------------------------

export function createMonitorRouter(): Router {
  const router = Router();

  // --- API Routes ---

  // All sessions
  router.get('/api/sessions', (_req: Request, res: Response) => {
    const allSessions = [...sessions.values()];
    const uniqueUsers = new Set(allSessions.map((s) => s.userConfig)).size;
    const uniqueIPs = new Set(allSessions.map((s) => s.ip)).size;

    res.json({
      sessions: allSessions.map((s) => {
        // Try to get a fresh title from cache if session still has raw ID
        const baseId = s.contentId.split(':')[0];
        const cacheKey = `${s.contentType}/${baseId}`;
        const cachedTitle = titleCache.get(cacheKey);
        let displayTitle = s.contentTitle;
        if (cachedTitle && cachedTitle !== baseId) {
          displayTitle = cachedTitle;
          const parts = s.contentId.split(':');
          if (parts.length >= 3) {
            displayTitle = `${cachedTitle} S${parts[1].padStart(2, '0')}E${parts[2].padStart(2, '0')}`;
          }
        }
        return {
          ...s,
          contentTitle: displayTitle,
          userConfigShort: s.userConfig.substring(0, 12) + '…',
          duration: Date.now() - s.firstSeen,
        };
      }),
      concurrentLimit: CONCURRENT_LIMIT,
      activeCount: allSessions.length,
      uniqueUsers,
      uniqueIPs,
    });
  });

  // Sessions for a specific user config
  router.get('/api/sessions/user/:userConfig', (req: Request, res: Response) => {
    const userConfig = req.params.userConfig as string;
    const userSessionsList = getActiveSessionsForUser(userConfig);
    res.json({
      sessions: userSessionsList,
      count: userSessionsList.length,
      limit: CONCURRENT_LIMIT,
    });
  });

  // Violations
  router.get('/api/violations', (req: Request, res: Response) => {
    const since = Number(req.query.since) || Date.now() - 86400000;
    const filtered = violations.filter((v) => v.timestamp >= since);
    res.json({
      violations: filtered,
      total: violations.length,
      blocked: filtered.filter((v) => v.blocked).length,
    });
  });

  // Stats summary
  router.get('/api/stats', (_req: Request, res: Response) => {
    const now = Date.now();
    const allSessions = [...sessions.values()];
    res.json({
      activeSessions: allSessions.length,
      concurrentLimit: CONCURRENT_LIMIT,
      sessionTimeout: SESSION_TIMEOUT,
      violations24h: violations.filter((v) => now - v.timestamp < 86400000)
        .length,
      blocked24h: violations.filter(
        (v) => now - v.timestamp < 86400000 && v.blocked
      ).length,
      uniqueUsers: new Set(allSessions.map((s) => s.userConfig)).size,
      uniqueIPs: new Set(allSessions.map((s) => s.ip)).size,
      capacityByUser: Object.fromEntries(
        [...userSessions.entries()].map(([user, uuids]) => [
          user.substring(0, 12) + '…',
          { active: uuids.size, limit: CONCURRENT_LIMIT },
        ])
      ),
    });
  });

  // Terminate a session by UUID
  router.post('/api/sessions/:uuid/terminate', (req: Request, res: Response) => {
    const uuid = req.params.uuid as string;
    if (deleteSession(uuid)) {
      logger.info(`Session ${uuid} terminated via monitor API`);
      res.json({ success: true, message: `Session ${uuid} terminated` });
    } else {
      res.status(404).json({ success: false, message: 'Session not found' });
    }
  });

  // Update settings at runtime
  router.put('/api/settings', (req: Request, res: Response) => {
    if (req.body.concurrentLimit != null) {
      CONCURRENT_LIMIT = Math.max(1, parseInt(req.body.concurrentLimit, 10));
    }
    if (req.body.sessionTimeout != null) {
      SESSION_TIMEOUT = Math.max(10000, parseInt(req.body.sessionTimeout, 10));
    }
    logger.info(
      `Monitor settings updated: limit=${CONCURRENT_LIMIT}, timeout=${SESSION_TIMEOUT}ms`
    );
    res.json({ concurrentLimit: CONCURRENT_LIMIT, sessionTimeout: SESSION_TIMEOUT });
  });

  // --- Network Stats (reads /proc/net/dev on Linux) ---
  let prevNetStats: { timestamp: number; rxBytes: number; txBytes: number } | null = null;

  let networkSource = 'none';

  function readNetworkStats(): { rxBytes: number; txBytes: number } | null {
    // Try host's /proc/net/dev first (mounted via volume), fall back to container's own
    const procPaths = ['/host/proc/net/dev', '/proc/net/dev'];
    for (const procPath of procPaths) {
      try {
        const data = fs.readFileSync(procPath, 'utf-8');
        const lines = data.split('\n').slice(2); // skip headers
        let totalRx = 0;
        let totalTx = 0;
        for (const line of lines) {
          const parts = line.trim().split(/\s+/);
          if (parts.length < 10) continue;
          const iface = parts[0].replace(':', '');
          // Exclude virtual/local loopback interfaces
          const isVirtualOrLoopback = /^(lo|docker|br-|veth|wg|tailscale|cni|cali|flannel|tun|tap|member|vnet|virbr)/i.test(iface);
          if (isVirtualOrLoopback) continue;
          totalRx += parseInt(parts[1], 10) || 0;
          totalTx += parseInt(parts[9], 10) || 0;
        }

        // Fallback: if everything was excluded, count any interface except loopback
        if (totalRx === 0 && totalTx === 0) {
          for (const line of lines) {
            const parts = line.trim().split(/\s+/);
            if (parts.length < 10) continue;
            const iface = parts[0].replace(':', '');
            if (/^lo/i.test(iface)) continue;
            totalRx += parseInt(parts[1], 10) || 0;
            totalTx += parseInt(parts[9], 10) || 0;
          }
        }

        if (networkSource !== procPath) {
          networkSource = procPath;
          logger.info(`[Monitor] Reading network stats from: ${procPath}`);
          // Log available interfaces for debugging
          const ifaces = lines
            .map(l => l.trim().split(/\s+/)[0]?.replace(':', ''))
            .filter(Boolean);
          logger.info(`[Monitor] Available interfaces: ${ifaces.join(', ')}`);
        }
        return { rxBytes: totalRx, txBytes: totalTx };
      } catch {
        continue;
      }
    }
    return null;
  }

  router.get('/api/network', (_req: Request, res: Response) => {
    const current = readNetworkStats();
    if (!current) {
      res.status(503).json({ error: 'Network stats not available (non-Linux OS)' });
      return;
    }

    const now = Date.now();
    let rxRate = 0;
    let txRate = 0;

    if (prevNetStats) {
      const elapsed = (now - prevNetStats.timestamp) / 1000; // seconds
      if (elapsed > 0) {
        rxRate = (current.rxBytes - prevNetStats.rxBytes) / elapsed;
        txRate = (current.txBytes - prevNetStats.txBytes) / elapsed;
      }
    }

    prevNetStats = { timestamp: now, rxBytes: current.rxBytes, txBytes: current.txBytes };

    res.json({
      source: networkSource,
      totalRxBytes: current.rxBytes,
      totalTxBytes: current.txBytes,
      rxBytesPerSec: Math.max(0, Math.round(rxRate)),
      txBytesPerSec: Math.max(0, Math.round(txRate)),
    });
  });

  // --- Static dashboard files ---
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = path.dirname(__filename);
  const dashboardPath = path.join(__dirname, '../static/monitor');
  router.use('/', (req: Request, res: Response, next: NextFunction) => {
    // Only serve static files for non-API paths
    if (req.path.startsWith('/api/')) return next();
    return express.static(dashboardPath)(req, res, next);
  });

  // Fallback: serve index.html for root
  router.get('/', (_req: Request, res: Response) => {
    res.sendFile(path.join(dashboardPath, 'index.html'));
  });

  return router;
}
