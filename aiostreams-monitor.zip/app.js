// ============================================
// AIOStreams Monitor — Dashboard Application
// ============================================

(function() {
    'use strict';

    // ============================================
    // State & Configuration
    // ============================================

    // API base path — when served from AIOStreams, this is relative.
    // When opened standalone (file://), API calls will fail and we fall back to demo mode.
    const API_BASE = '/monitor/api';
    let isLiveMode = false;

    const state = {
        concurrentLimit: 4,
        alertThreshold: 75, // percentage
        debridService: 'realdebrid',
        audioAlerts: true,
        autoTerminate: false,
        sessions: [],
        alerts: [],
        violations: [],
        timelineData: [],
        violationHistoryData: [],
        selectedRange: '1h',
    };

    // ============================================
    // API Client
    // ============================================
    async function apiFetch(path, options = {}) {
        const res = await fetch(`${API_BASE}${path}`, {
            headers: { 'Content-Type': 'application/json' },
            ...options,
        });
        if (!res.ok) throw new Error(`API ${res.status}: ${res.statusText}`);
        return res.json();
    }

    async function detectLiveMode() {
        try {
            const data = await apiFetch('/stats');
            if (data && typeof data.activeSessions === 'number') {
                isLiveMode = true;
                state.concurrentLimit = data.concurrentLimit || 4;
                return true;
            }
        } catch (e) {
            // API not available — demo mode
        }
        isLiveMode = false;
        return false;
    }

    // Debrid services metadata
    const DEBRID_SERVICES = {
        realdebrid:  { name: 'Real-Debrid',   color: '#6366f1', maxStreams: 4 },
        alldebrid:   { name: 'AllDebrid',      color: '#22d3ee', maxStreams: 3 },
        premiumize:  { name: 'Premiumize',     color: '#a78bfa', maxStreams: 5 },
        debridlink:  { name: 'Debrid-Link',    color: '#34d399', maxStreams: 3 },
        torbox:      { name: 'TorBox',         color: '#fb923c', maxStreams: 6 },
    };

    // Sample data pools
    const USERS = [
        { name: 'Alice M.', device: 'Shield TV', initials: 'AM' },
        { name: 'Bob K.', device: 'Fire Stick 4K', initials: 'BK' },
        { name: 'Charlie D.', device: 'Apple TV', initials: 'CD' },
        { name: 'Diana P.', device: 'iPhone 15', initials: 'DP' },
        { name: 'Ethan R.', device: 'Samsung TV', initials: 'ER' },
        { name: 'Fiona L.', device: 'iPad Pro', initials: 'FL' },
        { name: 'George W.', device: 'MacBook Pro', initials: 'GW' },
        { name: 'Hannah S.', device: 'Chromecast', initials: 'HS' },
    ];

    const CONTENT = [
        'Breaking Bad S05E16', 'The Bear S03E01', 'Dune: Part Two (2024)',
        'Oppenheimer (2023)', 'Severance S02E08', 'The Last of Us S02E03',
        'Shogun S01E10', 'Fallout S01E06', 'House of the Dragon S02E04',
        'Arcane S02E09', 'Interstellar (2014)', 'The Penguin S01E05',
        'Squid Game S02E07', 'Andor S02E12', 'Blade Runner 2049 (2017)',
    ];

    const IPS = [
        '192.168.1.42', '10.0.0.15', '172.16.0.88', '192.168.0.101',
        '10.0.1.33', '192.168.2.77', '203.0.113.5', '198.51.100.12',
    ];

    const SERVICES = ['realdebrid', 'alldebrid', 'premiumize', 'torbox', 'debridlink'];
    const STATUSES = ['streaming', 'streaming', 'streaming', 'buffering', 'paused'];
    const AVATAR_COLORS = [
        'linear-gradient(135deg, #6366f1, #8b5cf6)',
        'linear-gradient(135deg, #22d3ee, #06b6d4)',
        'linear-gradient(135deg, #f43f5e, #e11d48)',
        'linear-gradient(135deg, #fb923c, #f59e0b)',
        'linear-gradient(135deg, #34d399, #10b981)',
        'linear-gradient(135deg, #a78bfa, #7c3aed)',
        'linear-gradient(135deg, #f472b6, #ec4899)',
        'linear-gradient(135deg, #38bdf8, #0284c7)',
    ];

    // ============================================
    // DOM Elements
    // ============================================
    const dom = {};
    function cacheDom() {
        dom.activeStreamCount = document.getElementById('activeStreamCount');
        dom.concurrentLimit = document.getElementById('concurrentLimit');
        dom.violationCount = document.getElementById('violationCount');
        dom.uniqueIPCount = document.getElementById('uniqueIPCount');
        dom.streamTrend = document.getElementById('streamTrend');
        dom.streamTrendText = document.getElementById('streamTrendText');
        dom.violationTrend = document.getElementById('violationTrend');
        dom.violationTrendText = document.getElementById('violationTrendText');
        dom.capacityFill = document.getElementById('capacityFill');
        dom.ipWarning = document.getElementById('ipWarning');
        dom.limitLineValue = document.getElementById('limitLineValue');
        dom.limitLine = document.getElementById('limitLine');
        dom.sessionsBody = document.getElementById('sessionsBody');
        dom.alertsList = document.getElementById('alertsList');
        dom.alertBadge = document.getElementById('alertBadge');
        dom.donutLegend = document.getElementById('donutLegend');
        dom.donutTotal = document.getElementById('donutTotal');
        dom.timelineCanvas = document.getElementById('timelineCanvas');
        dom.donutCanvas = document.getElementById('donutCanvas');
        dom.violationsCanvas = document.getElementById('violationsCanvas');
        dom.sessionSearch = document.getElementById('sessionSearch');
        dom.lastUpdated = document.getElementById('lastUpdated');
        dom.toastContainer = document.getElementById('toastContainer');
        dom.settingsModal = document.getElementById('settingsModal');
        dom.settingsBtn = document.getElementById('settingsBtn');
        dom.settingsClose = document.getElementById('settingsClose');
        dom.settingsCancel = document.getElementById('settingsCancel');
        dom.settingsSave = document.getElementById('settingsSave');
        dom.limitSlider = document.getElementById('limitSlider');
        dom.limitDisplay = document.getElementById('limitDisplay');
        dom.thresholdSlider = document.getElementById('thresholdSlider');
        dom.thresholdDisplay = document.getElementById('thresholdDisplay');
        dom.debridSelect = document.getElementById('debridSelect');
        dom.audioToggle = document.getElementById('audioToggle');
        dom.autoTermToggle = document.getElementById('autoTermToggle');
        dom.clearAlertsBtn = document.getElementById('clearAlertsBtn');
        dom.kpiViolations = document.getElementById('kpiViolations');
        dom.connectionStatus = document.getElementById('connectionStatus');
        dom.alertsBtn = document.getElementById('alertsBtn');
    }

    // ============================================
    // Utility Functions
    // ============================================
    function rand(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    function pick(arr) {
        return arr[rand(0, arr.length - 1)];
    }

    function formatDuration(ms) {
        const secs = Math.floor(ms / 1000);
        const mins = Math.floor(secs / 60);
        const hrs = Math.floor(mins / 60);
        if (hrs > 0) return `${hrs}h ${mins % 60}m`;
        if (mins > 0) return `${mins}m ${secs % 60}s`;
        return `${secs}s`;
    }

    function timeAgo(ts) {
        const diff = Date.now() - ts;
        const secs = Math.floor(diff / 1000);
        if (secs < 60) return 'just now';
        const mins = Math.floor(secs / 60);
        if (mins < 60) return `${mins}m ago`;
        const hrs = Math.floor(mins / 60);
        return `${hrs}h ago`;
    }

    function generateUUID() {
        // RFC 4122 version 4 UUID
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = (Math.random() * 16) | 0;
            const v = c === 'x' ? r : (r & 0x3) | 0x8;
            return v.toString(16);
        });
    }

    function truncateUUID(uuid) {
        return uuid.substring(0, 8) + '…';
    }

    // ============================================
    // Session Management
    // ============================================
    function createSession() {
        const user = pick(USERS);
        const uuid = generateUUID();
        return {
            id: uuid,
            user: user.name,
            device: user.device,
            initials: user.initials,
            avatarColor: pick(AVATAR_COLORS),
            service: pick(SERVICES),
            ip: pick(IPS),
            content: pick(CONTENT),
            status: 'streaming',
            startTime: Date.now() - rand(10000, 3600000),
        };
    }

    function initSessionsDemo() {
        const count = rand(2, state.concurrentLimit);
        state.sessions = [];
        for (let i = 0; i < count; i++) {
            state.sessions.push(createSession());
        }
    }

    async function initSessionsLive() {
        try {
            const data = await apiFetch('/sessions');
            state.concurrentLimit = data.concurrentLimit || state.concurrentLimit;
            // Map API sessions to dashboard format
            state.sessions = data.sessions.map(s => ({
                id: s.uuid,
                user: s.userConfigShort || s.userConfig?.substring(0, 12) + '…',
                device: s.userAgent?.substring(0, 30) || 'Unknown',
                initials: (s.userConfig || 'U').substring(0, 2).toUpperCase(),
                avatarColor: pick(AVATAR_COLORS),
                service: detectServiceFromAgent(s.userAgent),
                ip: s.ip,
                content: s.contentType + '/' + s.contentId,
                status: 'streaming',
                startTime: s.firstSeen,
            }));
        } catch (e) {
            console.warn('Failed to fetch sessions from API:', e);
        }
    }

    function detectServiceFromAgent(ua) {
        if (!ua) return 'realdebrid';
        const lower = ua.toLowerCase();
        if (lower.includes('stremio')) return 'realdebrid';
        if (lower.includes('torbox')) return 'torbox';
        return pick(SERVICES);
    }

    function addSession() {
        const session = createSession();
        state.sessions.push(session);

        // Check for violation
        if (state.sessions.length > state.concurrentLimit) {
            session.status = 'violation';
            triggerViolation(session);
        } else {
            const pct = (state.sessions.length / state.concurrentLimit) * 100;
            if (pct >= state.alertThreshold) {
                addAlert('warning', 'Approaching Limit',
                    `${state.sessions.length}/${state.concurrentLimit} concurrent streams active (${Math.round(pct)}% capacity)`,
                    Date.now());
            }
        }

        updateAll();
    }

    async function removeSession(id) {
        if (isLiveMode) {
            try {
                await apiFetch(`/sessions/${id}/terminate`, { method: 'POST' });
            } catch (e) {
                showToast('critical', 'Terminate Failed', `Could not terminate session: ${e.message}`);
                return;
            }
        }
        state.sessions = state.sessions.filter(s => s.id !== id);
        updateAll();
        showToast('info', 'Session Terminated', `Session ${truncateUUID(id)} has been terminated`);
    }

    function triggerViolation(session) {
        state.violations.push({
            timestamp: Date.now(),
            sessionId: session.id,
            user: session.user,
            ip: session.ip,
            count: state.sessions.length,
            limit: state.concurrentLimit,
        });

        addAlert('critical', 'Concurrent Stream Violation!',
            `${state.sessions.length} active streams exceed limit of ${state.concurrentLimit}. Session: ${truncateUUID(session.id)} — ${session.user} (${session.ip})`,
            Date.now());

        showToast('critical', '🚨 Stream Violation Detected',
            `${state.sessions.length}/${state.concurrentLimit} concurrent streams — limit exceeded!`);

        // Update violation KPI visual
        dom.kpiViolations.classList.add('violation-active');
        setTimeout(() => dom.kpiViolations.classList.remove('violation-active'), 5000);

        if (state.autoTerminate) {
            setTimeout(() => {
                removeSession(session.id);
                showToast('success', 'Auto-terminated', `Session for ${session.user} was automatically terminated`);
            }, 2000);
        }
    }

    // ============================================
    // Alert Management
    // ============================================
    function addAlert(type, title, desc, timestamp) {
        state.alerts.unshift({ type, title, desc, timestamp, id: Math.random().toString(36).substr(2, 8) });
        if (state.alerts.length > 50) state.alerts.pop();
        renderAlerts();
        updateAlertBadge();
    }

    function clearAlerts() {
        state.alerts = [];
        renderAlerts();
        updateAlertBadge();
    }

    function updateAlertBadge() {
        const criticalCount = state.alerts.filter(a => a.type === 'critical').length;
        dom.alertBadge.textContent = criticalCount;
        dom.alertBadge.style.display = criticalCount > 0 ? 'flex' : 'none';
    }

    function renderAlerts() {
        if (state.alerts.length === 0) {
            dom.alertsList.innerHTML = `
                <div class="empty-state">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                        <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                    <span>No alerts — all clear!</span>
                </div>`;
            return;
        }

        dom.alertsList.innerHTML = state.alerts.slice(0, 20).map(alert => {
            const icons = {
                critical: '🔴',
                warning: '🟡',
                info: '🔵',
                success: '🟢',
            };
            return `
                <div class="alert-item">
                    <div class="alert-icon ${alert.type}">${icons[alert.type]}</div>
                    <div class="alert-body">
                        <div class="alert-title">${alert.title}</div>
                        <div class="alert-desc">${alert.desc}</div>
                        <div class="alert-time">${timeAgo(alert.timestamp)}</div>
                    </div>
                </div>`;
        }).join('');
    }

    // ============================================
    // Toast Notifications
    // ============================================
    function showToast(type, title, message) {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <div class="toast-title">${title}</div>
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close" onclick="this.closest('.toast').remove()">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
            <div class="toast-progress"></div>`;

        dom.toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.classList.add('removing');
            setTimeout(() => toast.remove(), 300);
        }, 4000);
    }

    // ============================================
    // Rendering
    // ============================================
    function updateKPIs() {
        const activeCount = state.sessions.length;
        const prevCount = parseInt(dom.activeStreamCount.textContent) || 0;

        // Animate count
        animateValue(dom.activeStreamCount, prevCount, activeCount, 400);

        // Concurrent limit
        dom.concurrentLimit.textContent = state.concurrentLimit;
        dom.limitLineValue.textContent = state.concurrentLimit;

        // Capacity bar
        const pct = Math.min((activeCount / state.concurrentLimit) * 100, 100);
        dom.capacityFill.style.width = pct + '%';
        dom.capacityFill.className = 'capacity-fill';
        if (pct >= 100) dom.capacityFill.classList.add('danger');
        else if (pct >= 75) dom.capacityFill.classList.add('warning');

        // Violations (24h)
        const violations24h = state.violations.filter(v => Date.now() - v.timestamp < 86400000).length;
        dom.violationCount.textContent = violations24h;

        // Unique IPs
        const uniqueIPs = new Set(state.sessions.map(s => s.ip)).size;
        dom.uniqueIPCount.textContent = uniqueIPs;

        // IP warning
        const ipEl = dom.ipWarning;
        if (uniqueIPs > 3) {
            ipEl.innerHTML = '<span class="ip-danger">⚠ Multiple IPs detected</span>';
        } else if (uniqueIPs > 2) {
            ipEl.innerHTML = '<span class="ip-warning">Moderate IP diversity</span>';
        } else {
            ipEl.innerHTML = '<span class="ip-safe">Within safe range</span>';
        }

        // Trends
        const diff = activeCount - prevCount;
        if (diff >= 0) {
            dom.streamTrend.className = 'kpi-trend up';
            dom.streamTrendText.textContent = `+${diff}`;
        } else {
            dom.streamTrend.className = 'kpi-trend down';
            dom.streamTrendText.textContent = `${diff}`;
        }
    }

    function animateValue(el, start, end, duration) {
        const startTime = performance.now();
        const diff = end - start;

        function step(time) {
            const progress = Math.min((time - startTime) / duration, 1);
            const ease = 1 - Math.pow(1 - progress, 3); // ease-out cubic
            el.textContent = Math.round(start + diff * ease);
            if (progress < 1) requestAnimationFrame(step);
        }

        requestAnimationFrame(step);
    }

    function renderSessions() {
        const filter = (dom.sessionSearch.value || '').toLowerCase();
        const filtered = state.sessions.filter(s => {
            if (!filter) return true;
            return s.id.toLowerCase().includes(filter)
                || s.user.toLowerCase().includes(filter)
                || s.device.toLowerCase().includes(filter)
                || s.ip.includes(filter)
                || s.content.toLowerCase().includes(filter)
                || s.status.includes(filter);
        });

        if (filtered.length === 0) {
            dom.sessionsBody.innerHTML = `
                <tr>
                    <td colspan="8">
                        <div class="empty-state">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                <circle cx="12" cy="12" r="10"/>
                                <line x1="12" y1="8" x2="12" y2="12"/>
                                <line x1="12" y1="16" x2="12.01" y2="16"/>
                            </svg>
                            <span>No active sessions</span>
                        </div>
                    </td>
                </tr>`;
            return;
        }

        dom.sessionsBody.innerHTML = filtered.map(s => {
            const dur = formatDuration(Date.now() - s.startTime);
            const service = DEBRID_SERVICES[s.service] || DEBRID_SERVICES.realdebrid;
            const statusClass = s.status;
            const statusLabel = s.status.charAt(0).toUpperCase() + s.status.slice(1);

            return `
                <tr data-id="${s.id}">
                    <td>
                        <div class="session-uuid-cell">
                            <span class="session-uuid" title="${s.id}">${truncateUUID(s.id)}</span>
                            <button class="btn-copy-uuid" onclick="window.__copyUUID('${s.id}')" title="Copy full UUID">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                            </button>
                        </div>
                    </td>
                    <td>
                        <div class="session-user">
                            <div class="session-avatar" style="background: ${s.avatarColor}">${s.initials}</div>
                            <div class="session-user-info">
                                <span class="session-username">${s.user}</span>
                                <span class="session-device">${s.device}</span>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="status-badge" style="background: ${hexToRgba(service.color, 0.1)}; color: ${service.color}">
                            <span class="status-badge-dot" style="background: ${service.color}"></span>
                            ${service.name}
                        </span>
                    </td>
                    <td><span class="session-ip">${s.ip}</span></td>
                    <td><span class="session-content" title="${s.content}">${s.content}</span></td>
                    <td><span class="session-duration">${dur}</span></td>
                    <td>
                        <span class="status-badge ${statusClass}">
                            <span class="status-badge-dot"></span>
                            ${statusLabel}
                        </span>
                    </td>
                    <td>
                        <button class="btn-terminate" onclick="window.__terminateSession('${s.id}')">End</button>
                    </td>
                </tr>`;
        }).join('');
    }

    function hexToRgba(hex, alpha) {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }

    // ============================================
    // Charts — Timeline (Canvas)
    // ============================================
    function generateTimelineData() {
        const points = 60;
        const data = [];
        const now = Date.now();
        for (let i = 0; i < points; i++) {
            const t = now - (points - i) * 60000;
            // Simulate stream counts with realistic patterns
            let base = rand(1, state.concurrentLimit);
            // Occasionally spike above limit
            if (Math.random() < 0.12) base = state.concurrentLimit + rand(1, 2);
            data.push({ time: t, count: Math.max(0, base) });
        }
        state.timelineData = data;
    }

    function drawTimeline() {
        const canvas = dom.timelineCanvas;
        const ctx = canvas.getContext('2d');
        const container = canvas.parentElement;
        const dpr = window.devicePixelRatio || 1;

        canvas.width = container.clientWidth * dpr;
        canvas.height = (container.clientHeight - 30) * dpr;
        ctx.scale(dpr, dpr);

        const w = container.clientWidth;
        const h = container.clientHeight - 30;

        ctx.clearRect(0, 0, w, h);

        const data = state.timelineData;
        if (data.length < 2) return;

        const maxVal = Math.max(state.concurrentLimit + 2, ...data.map(d => d.count));
        const padL = 35;
        const padR = 10;
        const padT = 10;
        const padB = 25;
        const chartW = w - padL - padR;
        const chartH = h - padT - padB;

        // Grid lines
        ctx.strokeStyle = 'rgba(255,255,255,0.04)';
        ctx.lineWidth = 1;
        for (let i = 0; i <= maxVal; i++) {
            const y = padT + chartH - (i / maxVal) * chartH;
            ctx.beginPath();
            ctx.moveTo(padL, y);
            ctx.lineTo(w - padR, y);
            ctx.stroke();

            // Labels
            ctx.fillStyle = 'rgba(255,255,255,0.2)';
            ctx.font = '10px "JetBrains Mono", monospace';
            ctx.textAlign = 'right';
            ctx.fillText(i.toString(), padL - 6, y + 3);
        }

        // Time labels
        ctx.fillStyle = 'rgba(255,255,255,0.15)';
        ctx.textAlign = 'center';
        ctx.font = '9px "JetBrains Mono", monospace';
        const labelCount = 6;
        for (let i = 0; i < labelCount; i++) {
            const idx = Math.floor((i / (labelCount - 1)) * (data.length - 1));
            const x = padL + (idx / (data.length - 1)) * chartW;
            const d = new Date(data[idx].time);
            ctx.fillText(`${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`, x, h - 2);
        }

        // Limit line position for HTML overlay
        const limitY = padT + chartH - (state.concurrentLimit / maxVal) * chartH;
        dom.limitLine.style.top = `${limitY + 16}px`;

        // Area fill
        const gradient = ctx.createLinearGradient(0, padT, 0, padT + chartH);
        gradient.addColorStop(0, 'rgba(99, 102, 241, 0.25)');
        gradient.addColorStop(1, 'rgba(99, 102, 241, 0)');

        ctx.beginPath();
        ctx.moveTo(padL, padT + chartH);
        data.forEach((d, i) => {
            const x = padL + (i / (data.length - 1)) * chartW;
            const y = padT + chartH - (d.count / maxVal) * chartH;
            if (i === 0) ctx.lineTo(x, y);
            else {
                // Smooth curve
                const prevX = padL + ((i - 1) / (data.length - 1)) * chartW;
                const prevY = padT + chartH - (data[i - 1].count / maxVal) * chartH;
                const cpx = (prevX + x) / 2;
                ctx.bezierCurveTo(cpx, prevY, cpx, y, x, y);
            }
        });
        ctx.lineTo(padL + chartW, padT + chartH);
        ctx.closePath();
        ctx.fillStyle = gradient;
        ctx.fill();

        // Line
        ctx.beginPath();
        data.forEach((d, i) => {
            const x = padL + (i / (data.length - 1)) * chartW;
            const y = padT + chartH - (d.count / maxVal) * chartH;
            if (i === 0) ctx.moveTo(x, y);
            else {
                const prevX = padL + ((i - 1) / (data.length - 1)) * chartW;
                const prevY = padT + chartH - (data[i - 1].count / maxVal) * chartH;
                const cpx = (prevX + x) / 2;
                ctx.bezierCurveTo(cpx, prevY, cpx, y, x, y);
            }
        });
        ctx.strokeStyle = '#6366f1';
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // Violation markers
        data.forEach((d, i) => {
            if (d.count > state.concurrentLimit) {
                const x = padL + (i / (data.length - 1)) * chartW;
                const y = padT + chartH - (d.count / maxVal) * chartH;

                // Glow
                ctx.beginPath();
                ctx.arc(x, y, 8, 0, Math.PI * 2);
                ctx.fillStyle = 'rgba(244, 63, 94, 0.15)';
                ctx.fill();

                // Point
                ctx.beginPath();
                ctx.arc(x, y, 4, 0, Math.PI * 2);
                ctx.fillStyle = '#f43f5e';
                ctx.fill();
                ctx.strokeStyle = 'rgba(244, 63, 94, 0.4)';
                ctx.lineWidth = 2;
                ctx.stroke();
            }
        });

        // Current point glow
        const lastD = data[data.length - 1];
        const lx = padL + chartW;
        const ly = padT + chartH - (lastD.count / maxVal) * chartH;
        ctx.beginPath();
        ctx.arc(lx, ly, 6, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(99, 102, 241, 0.2)';
        ctx.fill();
        ctx.beginPath();
        ctx.arc(lx, ly, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = '#6366f1';
        ctx.fill();
    }

    // ============================================
    // Charts — Donut (Canvas)
    // ============================================
    function drawDonut() {
        const canvas = dom.donutCanvas;
        const ctx = canvas.getContext('2d');
        const dpr = window.devicePixelRatio || 1;

        canvas.width = 200 * dpr;
        canvas.height = 200 * dpr;
        canvas.style.width = '200px';
        canvas.style.height = '200px';
        ctx.scale(dpr, dpr);

        const cx = 100, cy = 100, radius = 72, lineWidth = 22;
        ctx.clearRect(0, 0, 200, 200);

        // Count by service
        const counts = {};
        state.sessions.forEach(s => {
            counts[s.service] = (counts[s.service] || 0) + 1;
        });

        const total = state.sessions.length;
        dom.donutTotal.textContent = total;

        if (total === 0) {
            ctx.beginPath();
            ctx.arc(cx, cy, radius, 0, Math.PI * 2);
            ctx.strokeStyle = 'rgba(255,255,255,0.06)';
            ctx.lineWidth = lineWidth;
            ctx.stroke();
            dom.donutLegend.innerHTML = '';
            return;
        }

        // Draw segments
        let startAngle = -Math.PI / 2;
        const entries = Object.entries(counts);
        const gap = 0.04; // gap between segments

        entries.forEach(([service, count]) => {
            const sweepAngle = (count / total) * (Math.PI * 2 - gap * entries.length);
            const serviceData = DEBRID_SERVICES[service] || DEBRID_SERVICES.realdebrid;

            ctx.beginPath();
            ctx.arc(cx, cy, radius, startAngle, startAngle + sweepAngle);
            ctx.strokeStyle = serviceData.color;
            ctx.lineWidth = lineWidth;
            ctx.lineCap = 'round';
            ctx.stroke();

            startAngle += sweepAngle + gap;
        });

        // Legend
        dom.donutLegend.innerHTML = entries.map(([service, count]) => {
            const sd = DEBRID_SERVICES[service] || DEBRID_SERVICES.realdebrid;
            return `<div class="legend-item">
                <span class="legend-dot" style="background: ${sd.color}"></span>
                ${sd.name} (${count})
            </div>`;
        }).join('');
    }

    // ============================================
    // Charts — Violation History Bar Chart
    // ============================================
    function generateViolationHistory() {
        const data = [];
        const now = new Date();
        for (let i = 6; i >= 0; i--) {
            const d = new Date(now);
            d.setDate(d.getDate() - i);
            data.push({
                label: d.toLocaleDateString('en-US', { weekday: 'short' }),
                violations: rand(0, 5),
                warnings: rand(1, 8),
            });
        }
        state.violationHistoryData = data;
    }

    function drawViolationHistory() {
        const canvas = dom.violationsCanvas;
        const ctx = canvas.getContext('2d');
        const container = canvas.parentElement;
        const dpr = window.devicePixelRatio || 1;

        canvas.width = container.clientWidth * dpr;
        canvas.height = container.clientHeight * dpr;
        ctx.scale(dpr, dpr);

        const w = container.clientWidth;
        const h = container.clientHeight;
        ctx.clearRect(0, 0, w, h);

        const data = state.violationHistoryData;
        if (!data.length) return;

        const padL = 35, padR = 10, padT = 10, padB = 25;
        const chartW = w - padL - padR;
        const chartH = h - padT - padB;
        const barGroupWidth = chartW / data.length;
        const barWidth = Math.min(barGroupWidth * 0.3, 18);
        const maxVal = Math.max(10, ...data.map(d => Math.max(d.violations, d.warnings)));

        // Grid
        ctx.strokeStyle = 'rgba(255,255,255,0.04)';
        ctx.lineWidth = 1;
        for (let i = 0; i <= 5; i++) {
            const y = padT + chartH - (i / 5) * chartH;
            ctx.beginPath();
            ctx.moveTo(padL, y);
            ctx.lineTo(w - padR, y);
            ctx.stroke();

            ctx.fillStyle = 'rgba(255,255,255,0.2)';
            ctx.font = '9px "JetBrains Mono", monospace';
            ctx.textAlign = 'right';
            ctx.fillText(Math.round(i / 5 * maxVal).toString(), padL - 6, y + 3);
        }

        data.forEach((d, i) => {
            const groupX = padL + i * barGroupWidth + barGroupWidth / 2;

            // Warning bar
            const wH = (d.warnings / maxVal) * chartH;
            const wX = groupX - barWidth - 2;
            const wY = padT + chartH - wH;

            ctx.beginPath();
            ctx.roundRect(wX, wY, barWidth, wH, [4, 4, 0, 0]);
            ctx.fillStyle = 'rgba(251, 191, 36, 0.3)';
            ctx.fill();

            // Violation bar
            const vH = (d.violations / maxVal) * chartH;
            const vX = groupX + 2;
            const vY = padT + chartH - vH;

            ctx.beginPath();
            ctx.roundRect(vX, vY, barWidth, vH, [4, 4, 0, 0]);
            ctx.fillStyle = 'rgba(244, 63, 94, 0.5)';
            ctx.fill();

            // Label
            ctx.fillStyle = 'rgba(255,255,255,0.2)';
            ctx.font = '9px "JetBrains Mono", monospace';
            ctx.textAlign = 'center';
            ctx.fillText(d.label, groupX, h - 5);
        });

        // Mini legend
        const legY = padT + 2;
        ctx.font = '9px "Inter", sans-serif';

        ctx.fillStyle = 'rgba(251, 191, 36, 0.5)';
        ctx.beginPath();
        ctx.roundRect(w - padR - 135, legY, 8, 8, 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.fillText('Warnings', w - padR - 122, legY + 8);

        ctx.fillStyle = 'rgba(244, 63, 94, 0.6)';
        ctx.beginPath();
        ctx.roundRect(w - padR - 62, legY, 8, 8, 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.3)';
        ctx.fillText('Violations', w - padR - 49, legY + 8);
    }

    // ============================================
    // Update All
    // ============================================
    function updateAll() {
        updateKPIs();
        renderSessions();
        drawDonut();
        drawTimeline();
        updateAlertBadge();
        dom.lastUpdated.textContent = 'Updated just now';
    }

    // ============================================
    // Simulation Engine
    // ============================================
    let simInterval;

    // ============================================
    // Live Polling (API mode)
    // ============================================
    function startPolling() {
        // Poll sessions every 3 seconds
        setInterval(async () => {
            try {
                await initSessionsLive();

                // Update timeline
                state.timelineData.push({ time: Date.now(), count: state.sessions.length });
                if (state.timelineData.length > 120) state.timelineData.shift();

                // Check violations
                const prevViolationCount = state.violations.length;
                const violationData = await apiFetch('/violations?since=' + (Date.now() - 86400000));
                if (violationData.violations) {
                    state.violations = violationData.violations.map(v => ({
                        timestamp: v.timestamp,
                        sessionId: v.uuid,
                        user: v.userConfig?.substring(0, 12) + '…',
                        ip: v.ip,
                        count: v.activeCount,
                        limit: v.limit,
                    }));

                    // Alert on new violations
                    if (state.violations.length > prevViolationCount) {
                        const latest = violationData.violations[violationData.violations.length - 1];
                        if (latest && latest.blocked) {
                            addAlert('critical', '🚫 Stream Blocked!',
                                `User ${latest.userConfig?.substring(0, 8)}… blocked — ${latest.activeCount}/${latest.limit} streams`,
                                latest.timestamp);
                            showToast('critical', '🚫 Stream Blocked',
                                `Concurrent limit exceeded — stream request was rejected`);
                            dom.kpiViolations.classList.add('violation-active');
                            setTimeout(() => dom.kpiViolations.classList.remove('violation-active'), 5000);
                        }
                    }
                }

                updateAll();
            } catch (e) {
                // Silently handle polling errors
            }
        }, 3000);

        // Update violation history every 30 seconds
        setInterval(() => {
            drawViolationHistory();
        }, 30000);
    }

    // ============================================
    // Demo Simulation (standalone/offline mode)
    // ============================================
    function startSimulation() {
        // Update timeline data continuously
        setInterval(() => {
            const current = state.sessions.length;
            state.timelineData.push({ time: Date.now(), count: current });
            if (state.timelineData.length > 120) state.timelineData.shift();
            drawTimeline();
        }, 3000);

        // Session churn simulation
        simInterval = setInterval(() => {
            const action = Math.random();

            if (action < 0.35 && state.sessions.length < state.concurrentLimit + 3) {
                addSession();
            } else if (action < 0.55 && state.sessions.length > 1) {
                const idx = rand(0, state.sessions.length - 1);
                state.sessions.splice(idx, 1);
                updateAll();
            } else if (action < 0.7) {
                if (state.sessions.length > 0) {
                    const s = pick(state.sessions);
                    if (s.status !== 'violation') {
                        s.status = pick(STATUSES);
                    }
                    renderSessions();
                }
            } else if (action < 0.82 && state.sessions.length < state.concurrentLimit + 2) {
                addSession();
            }
            renderSessions();
        }, 5000);

        // Periodic alert generation
        setInterval(() => {
            if (Math.random() < 0.15) {
                const messages = [
                    { type: 'info', title: 'IP Change Detected', desc: `Device switched to IP ${pick(IPS)}` },
                    { type: 'warning', title: 'High Latency Warning', desc: `Proxy latency spike: ${rand(200, 800)}ms on ${pick(Object.values(DEBRID_SERVICES)).name}` },
                    { type: 'info', title: 'Session Renewed', desc: `Token refreshed for ${pick(USERS).name}` },
                    { type: 'warning', title: 'Rate Limit Warning', desc: `API rate approaching limit on ${pick(Object.values(DEBRID_SERVICES)).name}` },
                    { type: 'info', title: 'New Device Connected', desc: `${pick(USERS).device} joined the network` },
                ];
                const msg = pick(messages);
                addAlert(msg.type, msg.title, msg.desc, Date.now());
            }
        }, 8000);

        setInterval(() => { drawViolationHistory(); }, 30000);
    }

    // ============================================
    // Event Handlers
    // ============================================
    function bindEvents() {
        // Terminate session (exposed globally for onclick)
        window.__terminateSession = function(id) {
            removeSession(id);
        };

        // Copy UUID to clipboard
        window.__copyUUID = function(uuid) {
            navigator.clipboard.writeText(uuid).then(() => {
                showToast('success', 'UUID Copied', uuid);
            }).catch(() => {
                // Fallback for non-HTTPS contexts
                const ta = document.createElement('textarea');
                ta.value = uuid;
                ta.style.position = 'fixed';
                ta.style.opacity = '0';
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                document.body.removeChild(ta);
                showToast('success', 'UUID Copied', uuid);
            });
        };

        // Search
        dom.sessionSearch.addEventListener('input', () => {
            renderSessions();
        });

        // Settings modal
        dom.settingsBtn.addEventListener('click', () => {
            dom.limitSlider.value = state.concurrentLimit;
            dom.limitDisplay.textContent = state.concurrentLimit;
            dom.thresholdSlider.value = state.alertThreshold;
            dom.thresholdDisplay.textContent = state.alertThreshold + '%';
            dom.debridSelect.value = state.debridService;
            dom.audioToggle.checked = state.audioAlerts;
            dom.autoTermToggle.checked = state.autoTerminate;
            dom.settingsModal.classList.add('active');
        });

        function closeSettings() {
            dom.settingsModal.classList.remove('active');
        }

        dom.settingsClose.addEventListener('click', closeSettings);
        dom.settingsCancel.addEventListener('click', closeSettings);

        dom.settingsModal.addEventListener('click', (e) => {
            if (e.target === dom.settingsModal) closeSettings();
        });

        dom.limitSlider.addEventListener('input', () => {
            dom.limitDisplay.textContent = dom.limitSlider.value;
        });

        dom.thresholdSlider.addEventListener('input', () => {
            dom.thresholdDisplay.textContent = dom.thresholdSlider.value + '%';
        });

        dom.settingsSave.addEventListener('click', async () => {
            state.concurrentLimit = parseInt(dom.limitSlider.value);
            state.alertThreshold = parseInt(dom.thresholdSlider.value);
            state.debridService = dom.debridSelect.value;
            state.audioAlerts = dom.audioToggle.checked;
            state.autoTerminate = dom.autoTermToggle.checked;

            // Push settings to API in live mode
            if (isLiveMode) {
                try {
                    await apiFetch('/settings', {
                        method: 'PUT',
                        body: JSON.stringify({ concurrentLimit: state.concurrentLimit }),
                    });
                } catch (e) {
                    showToast('warning', 'API Error', 'Could not save settings to server');
                }
            }

            // Check for new violations with updated limit
            state.sessions.forEach(s => {
                if (state.sessions.indexOf(s) >= state.concurrentLimit && s.status !== 'violation') {
                    s.status = 'violation';
                }
            });

            updateAll();
            closeSettings();
            showToast('success', 'Settings Saved', `Concurrent limit set to ${state.concurrentLimit} streams`);
        });

        // Clear alerts
        dom.clearAlertsBtn.addEventListener('click', () => {
            clearAlerts();
            showToast('info', 'Alerts Cleared', 'All alerts have been dismissed');
        });

        // Range chips
        document.querySelectorAll('.chip[data-range]').forEach(chip => {
            chip.addEventListener('click', () => {
                document.querySelectorAll('.chip[data-range]').forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                state.selectedRange = chip.dataset.range;
                generateTimelineData();
                drawTimeline();
            });
        });

        // Alerts button scroll to alerts
        dom.alertsBtn.addEventListener('click', () => {
            document.getElementById('alertsCard').scrollIntoView({ behavior: 'smooth', block: 'center' });
        });

        // Window resize
        let resizeTimeout;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimeout);
            resizeTimeout = setTimeout(() => {
                drawTimeline();
                drawDonut();
                drawViolationHistory();
            }, 150);
        });
    }

    // ============================================
    // Initialization
    // ============================================
    async function init() {
        cacheDom();

        // Detect whether API is available
        const live = await detectLiveMode();

        if (live) {
            // LIVE MODE: fetch real data from AIOStreams middleware
            await initSessionsLive();
            generateTimelineData();
            generateViolationHistory();

            addAlert('info', 'Dashboard Online', 'Connected to AIOStreams — monitoring live concurrent streams', Date.now());

            updateAll();
            drawViolationHistory();
            bindEvents();
            startPolling();

            setTimeout(() => {
                showToast('success', 'Live Mode', 'Connected to AIOStreams API — real-time monitoring active');
            }, 500);

            // Update connection badge
            dom.connectionStatus.querySelector('.status-text').textContent = 'Live';
        } else {
            // DEMO MODE: simulated data for standalone use
            initSessionsDemo();
            generateTimelineData();
            generateViolationHistory();

            addAlert('info', 'Demo Mode', 'API not available — showing simulated data', Date.now());
            addAlert('warning', 'Approaching Limit', `${state.sessions.length}/${state.concurrentLimit} concurrent streams active`, Date.now() - 60000);

            updateAll();
            drawViolationHistory();
            bindEvents();
            startSimulation();

            setTimeout(() => {
                showToast('info', 'Demo Mode', 'API not available — using simulated data');
            }, 1500);

            // Update connection badge to show demo
            dom.connectionStatus.querySelector('.status-text').textContent = 'Demo';
            dom.connectionStatus.querySelector('.status-dot').classList.remove('live');
            dom.connectionStatus.style.background = 'rgba(251, 191, 36, 0.08)';
            dom.connectionStatus.style.borderColor = 'rgba(251, 191, 36, 0.2)';
            dom.connectionStatus.style.color = '#fbbf24';
        }
    }

    // Boot
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => init());
    } else {
        init();
    }
})();
