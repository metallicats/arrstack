const fs = require('fs');
const path = require('path');

const streamMonitorPath = path.join(__dirname, 'packages/server/src/middlewares/stream-monitor.ts');
const appJsPath = path.join(__dirname, 'app.js');
const indexCssPath = path.join(__dirname, 'index.css');
const indexHtmlPath = path.join(__dirname, 'index.html');

const streamMonitorContent = fs.readFileSync(streamMonitorPath, 'utf8');
const appJsContent = fs.readFileSync(appJsPath, 'utf8');
const indexCssContent = fs.readFileSync(indexCssPath, 'utf8');
const indexHtmlContent = fs.readFileSync(indexHtmlPath, 'utf8');

const installScript = `#!/usr/bin/env bash
# ============================================================
# AIOStreams Monitor Installer for Arrstack
# This script will:
# 1. Clone the latest AIOStreams repo
# 2. Inject the monitor middleware and dashboard files
# 3. Build a custom Docker image (aiostreams-monitor:latest)
# 4. Update your docker-compose.yml to use the new image
# 5. Restart the AIOStreams container
# ============================================================
set -e

echo "=== [1/6] Preparing AIOStreams Custom Build ==="
BUILD_DIR="aiostreams-custom-build"
rm -rf "$BUILD_DIR"
git clone https://github.com/Viren070/AIOStreams.git "$BUILD_DIR"
cd "$BUILD_DIR"

echo "=== [2/6] Writing Monitor Files ==="
mkdir -p packages/server/src/static/monitor

cat << 'EOF' > packages/server/src/middlewares/stream-monitor.ts
${streamMonitorContent}
EOF

cat << 'EOF' > packages/server/src/static/monitor/app.js
${appJsContent}
EOF

cat << 'EOF' > packages/server/src/static/monitor/index.css
${indexCssContent}
EOF

cat << 'EOF' > packages/server/src/static/monitor/index.html
${indexHtmlContent}
EOF

echo "=== [3/6] Patching Server Source Code ==="

# Patch middlewares/index.ts
echo "export * from './stream-monitor.js';" >> packages/server/src/middlewares/index.ts

# Patch app.ts - Add imports
sed -i "s/requireSessionIfAuthRequired,/requireSessionIfAuthRequired,\\n  streamMonitorMiddleware,\\n  createMonitorRouter,/" packages/server/src/app.ts

# Patch app.ts - Add streamMonitorMiddleware after loggerMiddleware
sed -i "s/app.use(loggerMiddleware);/app.use(loggerMiddleware);\\napp.use(streamMonitorMiddleware);/" packages/server/src/app.ts

# Patch app.ts - Mount /monitor router before Stremio Routes
sed -i "s/\\/\\/ Stremio Routes/\\/\\/ Stream Monitor Dashboard\\napp.use('\\/monitor', createMonitorRouter());\\n\\n\\/\\/ Stremio Routes/" packages/server/src/app.ts

# Patch Dockerfile to copy static files
sed -i "s/COPY packages\\/server \\.\\/packages\\/server/COPY packages\\/server \\.\\/packages\\/server\\nCOPY packages\\/server\\/src\\/static\\/monitor \\.\\/packages\\/server\\/src\\/static\\/monitor/" Dockerfile

echo "=== [4/6] Building Custom Docker Image (this may take a few minutes on ARM64) ==="
docker build -t aiostreams-monitor:latest .

cd ..
rm -rf "$BUILD_DIR"

echo "=== [5/6] Updating docker-compose.yml ==="
if [ -f "docker-compose.yml" ]; then
    sed -i 's/image: ghcr.io\\/viren070\\/aiostreams:latest/image: aiostreams-monitor:latest/' docker-compose.yml
    echo "docker-compose.yml updated successfully."
else
    echo "Warning: docker-compose.yml not found in current directory. Please update it manually."
fi

# Add Env vars to .env.aiostreams if not present
if [ -f ".env.aiostreams" ]; then
    if ! grep -q "MONITOR_CONCURRENT_LIMIT" .env.aiostreams; then
        echo "" >> .env.aiostreams
        echo "# Monitor Settings" >> .env.aiostreams
        echo "MONITOR_CONCURRENT_LIMIT=4" >> .env.aiostreams
        echo "MONITOR_SESSION_TIMEOUT=300000" >> .env.aiostreams
    fi
fi

echo "=== [6/6] Restarting AIOStreams Container ==="
if command -v docker-compose &> /dev/null; then
    docker-compose up -d aiostreams
elif docker compose version &> /dev/null; then
    docker compose up -d aiostreams
else
    echo "Docker compose not found, please start the container manually."
fi

echo ""
echo "============================================================"
echo "✅ Installation Complete!"
echo "The monitor is now available at: /monitor"
echo "Note: If using Nginx Proxy Manager, don't forget to protect"
echo "the /monitor path with Basic Auth or Access Lists."
echo "============================================================"
`;

fs.writeFileSync('install.sh', installScript);
console.log('install.sh generated successfully.');
